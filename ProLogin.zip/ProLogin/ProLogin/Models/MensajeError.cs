﻿namespace ProLogin.Models
{
    public class MensajeError
    {
        public string Error { get; set; }
    }
}
