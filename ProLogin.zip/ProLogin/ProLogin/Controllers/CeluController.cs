﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProLogin.Models;

namespace ProLogin.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CeluController : Controller
    {
        private readonly ApplicationDbContext context;

        public CeluController(ApplicationDbContext context)
        {
            this.context = context;
        }

        [HttpGet("{id:int}", Name = "ObtenerCelular")]
        public async Task<ActionResult<Celu>> GetObtenerCelu(int id)
        {
            var cel = await context.Celus.ToListAsync();

            if (cel == null || cel.Count == 0)
                return NotFound();

            return Ok(cel);
        }

        [HttpPost]
        public async Task<ActionResult> Post(Celu celu)
        {
            var celExiiste = await context.Celus.AnyAsync(x => x.Nombre == celu.Nombre);
            if (celExiiste)
                return BadRequest($"Celular {celu.Nombre} duplicado");

            context.Add(celu);
            await context.SaveChangesAsync();

            return Ok();
        }
        //TODO: Obtener todas las areas, en los errores o en las listas de tareas para ver lo de TODO

        [HttpPut("{id:int}")]
        public async Task<ActionResult> PutModificarCelu(int id, Celu celu)
        {
            var celExiste = await context.Celus.FirstOrDefaultAsync(x => x.Id == id);

            if (celExiste == null)
                return NotFound();

            celExiste.Nombre = celu.Nombre;
            celExiste.Descripcion = celu.Descripcion;

            context.Update(celu);
            await context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult> Eliminar(int id)
        {
            var celExiste = context.Celus.FirstOrDefaultAsync(x => x.Id == id);

            if (celExiste == null)
                return NotFound();

            context.Remove(celExiste);
            await context.SaveChangesAsync();
            return NoContent();
        }
    }
}
